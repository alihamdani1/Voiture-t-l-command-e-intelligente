#ifndef __BUZZER__
#define __BUZZER__

// Buzzer initialization
void initBuzzer();

// Function to turn on the buzzer
void buzzerOn();

// Function to turn off the buzzer
void buzzerOff();

#endif