#ifndef __I2C_LCD__
#define __I2C_LCD__

#define        I2C_ADDRESS  0x27

#define        AF_BASE      64
#define        AF_RS        (AF_BASE + 0)
#define        AF_RW        (AF_BASE + 1)
#define        AF_E         (AF_BASE + 2)
#define        AF_LED       (AF_BASE + 3)

#define        AF_DB4       (AF_BASE + 4)
#define        AF_DB5       (AF_BASE + 5)
#define        AF_DB6       (AF_BASE + 6)
#define        AF_DB7       (AF_BASE + 7)

// LCD initialization
int initLCD();

#endif
